﻿using Microsoft.EntityFrameworkCore;
using VacationManagementRESTService.Models;

namespace VacationManagementRESTService.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<VacationRequests> VacationRequests { get; set; }
        public DbSet<Roles> Roles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Users>()
                .HasKey(u => u.UserID);

            base.OnModelCreating(modelBuilder);
        }
    }
}
