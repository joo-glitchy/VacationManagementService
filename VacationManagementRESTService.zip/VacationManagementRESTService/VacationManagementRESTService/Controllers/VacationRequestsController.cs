using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VacationManagementRESTService.Data;
using VacationManagementRESTService.Models;

namespace VacationManagementRESTService.Controllers
{
    [Route("[controller]")]
    public class VacationRequestsController : Controller
    {
        private readonly AppDbContext _context;

        public VacationRequestsController(AppDbContext context)
        {
            _context = context;
        }

        // =========================
        // Dashboard
        // =========================
        [HttpGet("Index")]
        public IActionResult Index()
        {
            // Get the logged-in user's ID
            var userId = User.FindFirst("UserID")?.Value;

            // If nobody is logged in, go to login
            if (userId == null)
            {
                return RedirectToAction("Login", "Users");
            }

            // Find the logged-in user
            var currentUser = _context.Users
                .Include(u => u.Role)
                .FirstOrDefault(u => u.UserID.ToString() == userId);

            // If the user doesn't exist, go to login
            if (currentUser == null)
            {
                return RedirectToAction("Login", "Users");
            }

            var model = new VacationDashboardViewModel
            {
                UserID = currentUser.UserID,
                Firstname = currentUser.Firstname,
                Lastname = currentUser.Lastname,
                Role = currentUser.Role?.Name,
                Availablevacaydays = currentUser.Availablevacaydays,
                Sickdays = currentUser.Sickdays,

                MyRequests = _context.VacationRequests
                    .Where(r => r.EmployeeId == currentUser.UserID)
                    .OrderByDescending(r => r.VacationRequestId)
                    .ToList()
            };

            // If the logged-in user is a supervisor,
            // load all employees
            if (currentUser.Role?.Name == "supervisor")
            {
                model.Employees = _context.Users
                    .Include(u => u.Role)
                    .Where(u => u.Role != null &&
                                u.Role.Name == "employee")
                    .ToList();
            }

            // Send the model to Index.cshtml
            return View(model);
        }


        // =========================
        // Create vacation request
        // =========================
        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost("Create")]
        public IActionResult Create(DateTime Startdate, DateTime Enddate, string? Comment)
        {
            // Get the logged-in user's ID
            var userId = User.FindFirst("UserID")?.Value;

            if (userId == null)
            {
                return RedirectToAction("Login", "Users");
            }

            // Convert the ID from the login cookie into an integer
            if (!int.TryParse(userId, out int employeeId))
            {
                return RedirectToAction("Login", "Users");
            }

            // Make sure the end date isn't before the start date
            if (Enddate < Startdate)
            {
                ViewBag.Error = "End date cannot be before start date.";
                return View();
            }

            // Calculate number of vacation days
            int numberOfDays =
                (Enddate.Date - Startdate.Date).Days + 1;
            // Find the employee
            var employee = _context.Users
                .FirstOrDefault(u => u.UserID == employeeId);

            if (employee == null)
            {
                return RedirectToAction("Login", "Users");
            }

            // Check that the employee has enough vacation days
            if (numberOfDays > employee.Availablevacaydays)
            {
                ViewBag.Error = "You do not have enough vacation days.";
                return View();
            }

            // Create the vacation request
            var request = new VacationRequests
            {
                EmployeeId = employeeId,
                Startdate = Startdate,
                Enddate = Enddate,
                Numvacaydays = numberOfDays,
                Status = "pending",
                Comment = Comment
            };

            _context.VacationRequests.Add(request);

            // Reserve the vacation days immediately
            employee.Availablevacaydays -= numberOfDays;

            _context.SaveChanges();

            return RedirectToAction("Index");
        }


       


        [HttpPost("Withdraw")]
        public IActionResult Withdraw(int requestId)
        {
            var userId = User.FindFirst("UserID")?.Value;

            if (userId == null)
            {
                return RedirectToAction("Login", "Users");
            }

            if (!int.TryParse(userId, out int employeeId))
            {
                return RedirectToAction("Login", "Users");
            }

            var request = _context.VacationRequests
                .FirstOrDefault(r =>
                    r.VacationRequestId == requestId &&
                    r.EmployeeId == employeeId);

            if (request == null)
            {
                return NotFound();
            }

            // Employees can only withdraw pending requests
            if (request.Status != "pending")
            {
                return RedirectToAction("Index");
            }

            var employee = _context.Users
                .FirstOrDefault(u => u.UserID == employeeId);

            if (employee == null)
            {
                return RedirectToAction("Login", "Users");
            }

            // Give the reserved vacation days back
            employee.Availablevacaydays += request.Numvacaydays;

            // Mark the request as withdrawn
            request.Status = "withdrawn";

            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        // =========================
        // Approve vacation request
        // =========================
        [HttpGet("Approve")]
        public IActionResult Approve(int employeeId)
        {
            var userId = User.FindFirst("UserID")?.Value;

            if (userId == null)
            {
                return RedirectToAction("Login", "Users");
            }

            if (!int.TryParse(userId, out int supervisorId))
            {
                return RedirectToAction("Login", "Users");
            }

            // Make sure the logged-in user is actually a supervisor
            var supervisor = _context.Users
                .Include(u => u.Role)
                .FirstOrDefault(u => u.UserID == supervisorId);

            if (supervisor == null || supervisor.Role?.Name != "supervisor")
            {
                return Forbid();
            }

            // Find the selected employee
            var employee = _context.Users
                .FirstOrDefault(u => u.UserID == employeeId);

            if (employee == null)
            {
                return NotFound();
            }

            // Get this employee's pending requests
            var requests = _context.VacationRequests
                .Where(r =>
                    r.EmployeeId == employeeId &&
                    r.Status == "pending")
                .OrderBy(r => r.Startdate)
                .ToList();

            ViewBag.EmployeeName =
                $"{employee.Firstname} {employee.Lastname}";

            ViewBag.EmployeeId = employeeId;

            return View(requests);
        }

        [HttpPost("Decision")]
        public IActionResult Decision(int requestId, string decision)
        {
            var request = _context.VacationRequests
                .FirstOrDefault(r => r.VacationRequestId == requestId);

            if (request == null)
                return NotFound();

            if (request.Status != "pending")
                return RedirectToAction("Approve",
                    new { employeeId = request.EmployeeId });

            var employee = _context.Users
                .FirstOrDefault(u => u.UserID == request.EmployeeId);

            if (employee == null)
                return NotFound();

            if (decision == "approve")
            {
                request.Status = "approved";
            }
            else if (decision == "deny")
            {
                employee.Availablevacaydays += request.Numvacaydays;
                request.Status = "rejected";
            }

            _context.SaveChanges();

            return RedirectToAction(
                "Approve",
                new { employeeId = request.EmployeeId });
        }
    }
}
