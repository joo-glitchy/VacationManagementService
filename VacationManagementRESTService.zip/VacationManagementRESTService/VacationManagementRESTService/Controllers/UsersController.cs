using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VacationManagementRESTService.Data;
using VacationManagementRESTService.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace VacationManagementRESTService.Controllers
{
    [Route("[controller]")]
    public class UsersController : Controller
    {
        private readonly AppDbContext _context;

        public UsersController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("Login")]
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost("Login")]
        public async Task<IActionResult> Login(string Email, string Code)
        {
            // Find the role using the login code
            var role = _context.Roles
                .FirstOrDefault(r => r.Code == Code);

            if (role == null)
            {
                ViewBag.Error = "Invalid email or code.";
                return View();
            }

            // Find the user
            var user = _context.Users
                .FirstOrDefault(u =>
                    u.Email == Email &&
                    u.RoleId == role.RoleId);

            if (user == null)
            {
                ViewBag.Error = "Invalid email or code.";
                return View();
            }

            // Create claims
            var claims = new List<Claim>
            {
                new Claim("UserID", user.UserID.ToString()),
                new Claim(ClaimTypes.Name, user.Firstname ?? ""),
                new Claim(ClaimTypes.Email, user.Email ?? ""),
                new Claim(ClaimTypes.Role, role.Name)
            };

            var identity = new ClaimsIdentity(
                claims,
                CookieAuthenticationDefaults.AuthenticationScheme
            );

            var principal = new ClaimsPrincipal(identity);

            // Sign the user in
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal
            );

            return RedirectToAction(
                "Index",
                "VacationRequests"
            );
        }


        [HttpGet("Register")]
        public IActionResult Register()
        {
            return View();
        }


        [HttpPost("Register")]
        public IActionResult Register(RegisterModel model)
        {
            var existingUser = _context.Users
                .FirstOrDefault(u => u.Email == model.Email);

            if (existingUser != null)
            {
                ViewBag.Error = "An account with this email already exists.";
                return View(model);
            }

            var role = _context.Roles
                .FirstOrDefault(r => r.Code == model.Code);

            if (role == null)
            {
                ViewBag.Error = "Invalid registration code.";
                return View(model);
            }

            var user = new Users
            {
                Firstname = model.Firstname,
                Lastname = model.Lastname,
                Email = model.Email,
                RoleId = role.RoleId,
                Availablevacaydays = 30,
                Sickdays = 0
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            return RedirectToAction("Login");
        }


        [HttpGet]
        public IActionResult Get()
        {
            var users = _context.Users
                .Include(u => u.Role)
                .ToList();

            return Json(users);
        }
    }
}
