﻿using Microsoft.AspNetCore.Mvc;

namespace VacationManagementRESTService.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
