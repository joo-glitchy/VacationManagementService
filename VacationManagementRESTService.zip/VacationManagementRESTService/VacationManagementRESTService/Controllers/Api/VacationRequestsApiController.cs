﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VacationManagementRESTService.Data;

namespace VacationManagementRESTService.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class VacationRequestsApiController : ControllerBase
    {
        private readonly AppDbContext _context;

        public VacationRequestsApiController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var requests = _context.VacationRequests
                .Include(r => r.Employee)
                .Select(r => new
                {
                    r.VacationRequestId,
                    r.EmployeeId,
                    EmployeeName = r.Employee != null
                        ? r.Employee.Firstname + " " + r.Employee.Lastname
                        : null,
                    r.Startdate,
                    r.Enddate,
                    r.Numvacaydays,
                    r.Status,
                    r.Comment
                })
                .ToList();

            return Ok(requests);
        }
    }
}