using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;

namespace VacationManagementRESTService.Models

{
    [Table("users")]
    public class Users
    {
        [Key]
        public int UserID { get; set; }

        public string? Firstname { get; set; }

        public string? Lastname { get; set; }

        public string? Email { get; set; }
        public int RoleId { get; set; }
        public Roles Role { get; set; }
        public int Availablevacaydays { get; set; }
        public int Sickdays { get; set; }
    }
}
