﻿namespace VacationManagementRESTService.Models
{
    public class LoginModel
    {
        public string? Email { get; set; }
        public string? Code { get; set; }
    }
}
