using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VacationManagementRESTService.Models
{
    public class VacationRequests
    {
        [Key]
        public int VacationRequestId { get; set; }
        public int EmployeeId { get; set; }
        [ForeignKey("EmployeeId")]
        public Users? Employee { get; set; }
        public DateTime Startdate { get; set; }
        public DateTime Enddate { get; set; }
        public int Numvacaydays { get; set; }
        public string? Status { get; set; }
        public string? Comment { get; set; }


    }
}
