﻿namespace VacationManagementRESTService.Models
{
    public class RegisterModel
    {
        public string? Firstname { get; set; }

        public string? Lastname { get; set; }

        public string? Email { get; set; }

        public string? Code{ get; set; }
    }
}

