﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VacationManagementRESTService.Models
{
    [Table("roles")]
    public class Roles
    {
        [Key]
        public int RoleId { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }

        public ICollection<Users> Users { get; set; }
    }
}
