﻿namespace VacationManagementRESTService.Models
{
    public class VacationDashboardViewModel
    {
        public int UserID { get; set; }
        public string? Firstname { get; set; }
        public string? Lastname { get; set; }
        public string? Role { get; set; }
        public int Availablevacaydays { get; set; }
        public int Sickdays { get; set; }

        public List<Users> Employees { get; set; } = new List<Users>();

        public List<VacationRequests> MyRequests { get; set; }
            = new List<VacationRequests>();
    }
}